from pathlib import Path

app_name = "midas"
app_entrypoint = "midas.backend.app:app"
app_slug = "midas"
api_prefix = "/api"
dist_dir = Path(__file__).parent / "__dist__"